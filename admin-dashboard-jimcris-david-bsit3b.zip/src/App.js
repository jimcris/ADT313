import * as React from 'react';
import * as ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import './index.css';
import Login from './pages/Public/Login/Login';
import Dashboard from './pages/Main/Dashboard/Dashboard';
import Main from './pages/Main/Main';
import Register from './pages/Public/Login/Register'; // Import Register component

const router = createBrowserRouter([
  {
    path: '/',               // The root path points to the login page
    element: <Login />,
  },
  {
    path: '/register',        // Add the Register page route
    element: <Register />,
  },
  {
    path: '/main',            // Main layout route
    element: <Main />,
    children: [
      {
        path: 'dashboard',    // Nested route for the dashboard
        element: <Dashboard />,
      },
    ],
  },
]);

function App() {
  return (
    <div className='App'>
      <RouterProvider router={router} />
    </div>
  );
}

export default App;
